"use client";

export default function Error() {
  return (
    <div>
      <h1>500 ERROR</h1>
    </div>
  );
}
