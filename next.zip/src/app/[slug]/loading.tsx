import LoadingSkeleton from "@/components/core/LoadingSkeleton";

export default function Loading() {
  return <LoadingSkeleton />;
}
