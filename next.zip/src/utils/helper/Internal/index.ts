export function getInternalBaseUrl() {
  return process.env.INTERNAL_BASE_URL;
}
